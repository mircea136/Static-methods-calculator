
<?php

include("./newCalculator.php");



NewCalculator::add(6); 
echo "Add:  ". NewCalculator::getValue(); 

echo "<br/>";

NewCalculator::substract(4); 
echo "Substract:   ".NewCalculator::getValue(); 

echo "<br/>";

NewCalculator::multiply(44); 
echo "Multiply:   ".NewCalculator::getValue(); 

echo "<br/>";

NewCalculator::divide(7); 
echo "Divide:   ".NewCalculator::getValue(); 

echo "<br/>";

NewCalculator::modulo(8); 
echo "Modulo:  ".NewCalculator::getValue();

echo "<br/>";

echo NewCalculator::squareRoot(); 
echo "Square Root:   ".NewCalculator::getValue();

echo "<br/>";

echo NewCalculator::square();
echo "Square:    ".NewCalculator::getValue();

echo "<br/>";


NewCalculator::setValue(768);
echo "Set value: ". NewCalculator::getValue();

echo "<br/>";

NewCalculator::clearC();
echo "Clear - the new value is ".NewCalculator::getValue();

