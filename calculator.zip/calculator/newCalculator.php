
<?php

class NewCalculator {

    public static $value = 0;

    public static function getValue() {
        return static::$value;
    }

    public static function setValue(float $number) {
        self::$value = $number;
        return static::$value;
    }

    public static function clearC() {
        self::$value = 0;
        return static::$value;
    }

    public static function add(float $number) {
        self::$value += $number;
    }

    public static function substract(float $number) {

        self::$value -= $number;
    }

    public static function multiply(float $number) {
        self::$value *= $number;
    }

    public static function divide(float $number) {

        self::$value /= $number;
    }

    public static function modulo(float $number) {

        self::$value %= $number;
    }

    public static function square() {

        self::$value = self::$value ** 2;
    }

    public static function squareRoot() {

        self::$value = sqrt(self::$value);
    }

}